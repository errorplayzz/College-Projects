// import logo from './logo.svg';
import './App.css';
import Textform from './Components/Textform';
import Alert from './Components/Alert';

function App() {
  return (
    <>
      <Alert alert={alert}/>
      <Textform heading="head" />
    </>


  );
}

export default App;
